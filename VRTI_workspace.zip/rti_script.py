import bpy
import os

# Set the output folder
output_folder = "your file path"
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Get all lights only from the "row 1 lights", "row 2 lights" and "row 3 lights" folders
collections = [bpy.data.collections.get("lights1"), bpy.data.collections.get("lights2"), bpy.data.collections.get("lights3")]
lights = [obj for collection in collections if collection for obj in collection.objects if obj.type == 'LIGHT']

# Save the original settings
original_output_path = bpy.context.scene.render.filepath
original_image_format = bpy.context.scene.render.image_settings.file_format

# Set the output format to JPEG
bpy.context.scene.render.image_settings.file_format = 'JPEG'

# Render each light individually
for light in lights:
    # Disable all other lights
    for l in lights:
        l.hide_render = True

    # Turn on the current light only
    light.hide_render = False

    # Set the path to the output file
    bpy.context.scene.render.filepath = os.path.join(output_folder, f"{light.name}.jpg")

    # Start rendering
    bpy.ops.render.render(write_still=True)

    # Disable the current light
    light.hide_render = True

# Restore the original path and image format
bpy.context.scene.render.filepath = original_output_path
bpy.context.scene.render.image_settings.file_format = original_image_format

print("Rendering completed!")
